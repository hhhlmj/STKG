"""Initialize the TTD transform."""
