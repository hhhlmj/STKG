"""Initialize the GO-CAM transform."""

from .gocam_transform import GocamTransform

__all__ = ["GocamTransform"]
