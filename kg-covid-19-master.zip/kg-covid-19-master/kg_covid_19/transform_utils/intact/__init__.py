"""Initialize IntAct transform."""
