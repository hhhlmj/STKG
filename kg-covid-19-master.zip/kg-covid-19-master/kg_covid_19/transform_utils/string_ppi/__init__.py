"""Initialze STRING PPI transform."""

from .string_ppi import StringTransform

__all__ = ["StringTransform"]
