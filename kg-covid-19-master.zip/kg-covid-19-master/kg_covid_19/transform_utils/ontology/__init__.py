"""Initialize Ontology transform."""

from .ontology_transform import OntologyTransform

__all__ = ["OntologyTransform"]
