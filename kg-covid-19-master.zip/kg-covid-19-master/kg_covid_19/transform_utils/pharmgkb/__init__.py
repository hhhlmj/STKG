"""Initialize PharmGKB transform."""

from .pharmgkb import PharmGKB

__all__ = ["PharmGKB"]
