---
name: Feature request
about: Suggest a new feature to add to the KG-COVID-19 software framework
title: ''
labels: enhancement
assignees: ''

---
(Note: this template is for requesting new features in the software, not new datasets to ingest. Use the "Dataset request" for that.)

### Describe the desired behavior

## Additional context
